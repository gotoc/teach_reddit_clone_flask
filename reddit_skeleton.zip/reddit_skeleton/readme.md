# Build a Reddit Clone from the Ground Up

## Install Dependencies

    pip install -r requirements.txt

How to install pip on
+ [Windows](http://stackoverflow.com/questions/4750806/how-to-install-pip-on-windows)
+ [OSX](http://stackoverflow.com/questions/17271319/installing-pip-on-mac-os-x)
+ [Linux](http://ask.xmodulo.com/install-pip-linux.html)

## Run it

    python run.py

## Link to Slides
(todo: shazeline)

## Link to Video
(todo: acm media team)
